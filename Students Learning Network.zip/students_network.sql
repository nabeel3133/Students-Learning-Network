-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 06, 2018 at 11:30 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `students_network`
--

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE IF NOT EXISTS `course` (
  `ID` int(255) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`ID`, `Name`) VALUES
(1, 'Mathematics'),
(2, 'Chemistry'),
(3, 'English'),
(4, 'Computer Science'),
(5, 'Physics');

-- --------------------------------------------------------

--
-- Table structure for table `instructor_subjects`
--

CREATE TABLE IF NOT EXISTS `instructor_subjects` (
  `Instructor_ID` varchar(255) NOT NULL,
  `Subject_ID` int(255) NOT NULL,
  `Subject_Name` varchar(255) NOT NULL,
  KEY `Instructor_ID` (`Instructor_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `instructor_subjects`
--

INSERT INTO `instructor_subjects` (`Instructor_ID`, `Subject_ID`, `Subject_Name`) VALUES
('fahad', 1, 'Mathematics'),
('fahad', 2, 'Chemistry'),
('nabeel', 1, 'Mathematics'),
('fahad', 3, 'English');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `ID` int(255) NOT NULL AUTO_INCREMENT,
  `Sender_ID` varchar(255) NOT NULL,
  `Message` varchar(255) NOT NULL,
  `Session_ID` int(255) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Sender_ID` (`Sender_ID`),
  KEY `Session_ID` (`Session_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`ID`, `Sender_ID`, `Message`, `Session_ID`) VALUES
(25, 'baou', 'Hello', 2);

-- --------------------------------------------------------

--
-- Table structure for table `newsdata`
--

CREATE TABLE IF NOT EXISTS `newsdata` (
  `ID` int(255) NOT NULL AUTO_INCREMENT,
  `Instructor_ID` varchar(255) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `News` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Instructor_ID` (`Instructor_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `newsdata`
--

INSERT INTO `newsdata` (`ID`, `Instructor_ID`, `Title`, `News`) VALUES
(2, 'fahad', 'Binomial Induction', 'There will be quiz of this topic tonight so be prepared.');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE IF NOT EXISTS `question` (
  `ID` int(255) NOT NULL AUTO_INCREMENT,
  `Quiz_ID` int(255) NOT NULL,
  `Question` varchar(255) NOT NULL,
  `Marks` int(255) NOT NULL,
  `Correct_Answer` int(255) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Quiz_ID` (`Quiz_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=57 ;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`ID`, `Quiz_ID`, `Question`, `Marks`, `Correct_Answer`) VALUES
(52, 25, 'Ques1', 1, 1),
(53, 25, 'Ques2', 1, 2),
(54, 25, 'Ques3', 1, 3),
(55, 25, 'Ques4', 1, 4),
(56, 25, 'Ques5', 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE IF NOT EXISTS `quiz` (
  `ID` int(255) NOT NULL AUTO_INCREMENT,
  `Topic_ID` int(255) NOT NULL,
  `Marks` int(255) NOT NULL,
  `Topic_Name` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Topic_ID` (`Topic_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`ID`, `Topic_ID`, `Marks`, `Topic_Name`) VALUES
(25, 1, 5, 'Binomial Induction');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE IF NOT EXISTS `review` (
  `ID` int(255) NOT NULL AUTO_INCREMENT,
  `Quiz_ID` int(255) NOT NULL,
  `Student_ID` varchar(255) NOT NULL,
  `Marks` int(255) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Quiz_ID` (`Quiz_ID`),
  KEY `Student_ID` (`Student_ID`),
  KEY `Marks` (`Marks`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`ID`, `Quiz_ID`, `Student_ID`, `Marks`) VALUES
(8, 25, 'baou', 4),
(14, 25, 'zari', 1);

-- --------------------------------------------------------

--
-- Table structure for table `session`
--

CREATE TABLE IF NOT EXISTS `session` (
  `ID` int(255) NOT NULL AUTO_INCREMENT,
  `Stud1_ID` varchar(255) NOT NULL,
  `Stud2_ID` varchar(255) NOT NULL,
  `Instructor_ID` varchar(255) NOT NULL,
  `Topic_ID` int(255) NOT NULL,
  `Refer1` tinyint(1) DEFAULT NULL,
  `Refer2` tinyint(1) DEFAULT NULL,
  `Accept1` tinyint(1) DEFAULT NULL,
  `Accept2` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Stud1_ID` (`Stud1_ID`),
  KEY `Stud2_ID` (`Stud2_ID`),
  KEY `Instructor_ID` (`Instructor_ID`),
  KEY `Topic_ID` (`Topic_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `session`
--

INSERT INTO `session` (`ID`, `Stud1_ID`, `Stud2_ID`, `Instructor_ID`, `Topic_ID`, `Refer1`, `Refer2`, `Accept1`, `Accept2`) VALUES
(2, 'zari', 'baou', 'fahad', 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `topic`
--

CREATE TABLE IF NOT EXISTS `topic` (
  `ID` int(255) NOT NULL AUTO_INCREMENT,
  `Course_ID` int(255) NOT NULL,
  `Name` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Course_ID` (`Course_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `topic`
--

INSERT INTO `topic` (`ID`, `Course_ID`, `Name`) VALUES
(1, 1, 'Binomial Induction'),
(10, 1, 'Sequences And Series'),
(11, 2, 'Inorganic Chemistry'),
(12, 3, 'Mr Chips');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Type` varchar(255) NOT NULL,
  PRIMARY KEY (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Username`, `Password`, `Type`) VALUES
('baou', '123', 'Student'),
('fahad', '123', 'Instructor'),
('muzahir', '123', 'Admin'),
('nabeel', '123', 'Instructor'),
('zari', '123', 'Student');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `instructor_subjects`
--
ALTER TABLE `instructor_subjects`
  ADD CONSTRAINT `instructor_subjects_ibfk_1` FOREIGN KEY (`Instructor_ID`) REFERENCES `user` (`Username`);

--
-- Constraints for table `message`
--
ALTER TABLE `message`
  ADD CONSTRAINT `message_ibfk_1` FOREIGN KEY (`Session_ID`) REFERENCES `session` (`ID`),
  ADD CONSTRAINT `message_ibfk_2` FOREIGN KEY (`Sender_ID`) REFERENCES `user` (`Username`);

--
-- Constraints for table `newsdata`
--
ALTER TABLE `newsdata`
  ADD CONSTRAINT `newsdata_ibfk_1` FOREIGN KEY (`Instructor_ID`) REFERENCES `user` (`Username`);

--
-- Constraints for table `question`
--
ALTER TABLE `question`
  ADD CONSTRAINT `question_ibfk_1` FOREIGN KEY (`Quiz_ID`) REFERENCES `quiz` (`ID`);

--
-- Constraints for table `quiz`
--
ALTER TABLE `quiz`
  ADD CONSTRAINT `quiz_ibfk_1` FOREIGN KEY (`Topic_ID`) REFERENCES `topic` (`ID`);

--
-- Constraints for table `review`
--
ALTER TABLE `review`
  ADD CONSTRAINT `review_ibfk_1` FOREIGN KEY (`Quiz_ID`) REFERENCES `quiz` (`ID`);

--
-- Constraints for table `session`
--
ALTER TABLE `session`
  ADD CONSTRAINT `session_ibfk_1` FOREIGN KEY (`Stud1_ID`) REFERENCES `user` (`Username`),
  ADD CONSTRAINT `session_ibfk_2` FOREIGN KEY (`Stud2_ID`) REFERENCES `user` (`Username`),
  ADD CONSTRAINT `session_ibfk_3` FOREIGN KEY (`Instructor_ID`) REFERENCES `user` (`Username`),
  ADD CONSTRAINT `session_ibfk_4` FOREIGN KEY (`Topic_ID`) REFERENCES `topic` (`ID`);

--
-- Constraints for table `topic`
--
ALTER TABLE `topic`
  ADD CONSTRAINT `topic_ibfk_1` FOREIGN KEY (`Course_ID`) REFERENCES `course` (`ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
