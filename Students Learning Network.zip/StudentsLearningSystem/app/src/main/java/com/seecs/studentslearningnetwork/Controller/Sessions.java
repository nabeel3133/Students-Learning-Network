package com.seecs.studentslearningnetwork.Controller;

import android.content.Intent;
import android.os.*;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.seecs.studentslearningnetwork.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Sessions extends AppCompatActivity {
    String username;
    Intent messengerActivity;
    ListView sessions;
    ArrayList<String> idarray = new ArrayList<>();
    ArrayList<String> topicnamearray = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sessions);
        Bundle bundle = getIntent().getExtras();
        username = bundle.getString("Username");
        try {
            new sessionget().execute().get();
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
        final ListView listview = findViewById(R.id.sessions);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, android.R.id.text1,topicnamearray);
        listview.setAdapter(adapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> arg0, View v, int position,
                                    long arg3)
            {
                int pos = position;
                messengerActivity = new Intent(getApplicationContext(), Messenger.class);
                messengerActivity.putExtra("Username", username);
                messengerActivity.putExtra("Session", idarray.get(pos));
                startActivity(messengerActivity);
            }
        });
    }
    public class sessionget extends AsyncTask {
        public sessionget(){}
        @Override
        protected Object doInBackground(Object[] objects)
        {
            String link = "http://10.0.2.2/getallsessions.php?user="+username;
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(link)
                    .build();
            try {
                Response response = client.newCall(request).execute();
                String result = response.body().string();
                JSONObject json = new JSONObject(result);
                JSONArray jarray = json.getJSONArray("AllSessions");
                for (int i=0;i<jarray.length();i++)
                {
                    JSONObject id = jarray.getJSONObject(i);
                    idarray.add(id.getString("id"));
                    topicnamearray.add(id.getString("topic"));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
