package com.seecs.studentslearningnetwork.Model;

/**
 * Created by Nabeel Hussain Syed on 12/27/2017.
 */

public class User {
    private String username;
    private String name;
    private String password;
    private char type;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public char getType() {
        return type;
    }

    public void setType(char type) {
        this.type = type;
    }
}
