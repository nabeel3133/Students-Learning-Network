package com.seecs.studentslearningnetwork.Controller;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.seecs.studentslearningnetwork.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import okhttp3.OkHttpClient;

public class AttemptQuiz extends AppCompatActivity {

    String TAG = "MYTAG";

    TextView topicNameView;
    TextView Question1View;
    TextView Question2View;
    TextView Question3View;
    TextView Question4View;
    TextView Question5View;

    EditText Answer1View;
    EditText Answer2View;
    EditText Answer3View;
    EditText Answer4View;
    EditText Answer5View;
    Intent StudentCoursesActivity;

    String username;
    String Topic_name;

    String answer1;
    String answer2;
    String answer3;
    String answer4;
    String answer5;

    ArrayList<String> All_Questions = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attempt_quiz);

        Bundle bundle = getIntent().getExtras();
        username = bundle.getString("Username");

        StudentCoursesActivity = new Intent(getApplicationContext(),ShowCoursesAndTopics.class);

        Log.d(TAG,"Username: "+username);
        Topic_name = bundle.getString("TopicName");
        Log.d(TAG,"Topic is: "+Topic_name);
        topicNameView = (TextView)findViewById(R.id.tV_TopicName);
        topicNameView.setText(Topic_name);

        try {
            boolean AllQuestions = (Boolean) new Student_GetQuizQuestions().execute().get();
        }
        catch (Exception ex){
            ex.printStackTrace();
        }

        Question1View = (TextView)findViewById(R.id.tV_Question1);
        Question2View = (TextView)findViewById(R.id.tV_Question2);
        Question3View = (TextView)findViewById(R.id.tV_Question3);
        Question4View = (TextView)findViewById(R.id.tV_Question4);
        Question5View = (TextView)findViewById(R.id.tV_Question5);

        Question1View.setText("Question 1: "+All_Questions.get(0).toString());
        Question2View.setText("Question 2: "+All_Questions.get(1).toString());
        Question3View.setText("Question 3: "+All_Questions.get(2).toString());
        Question4View.setText("Question 4: "+All_Questions.get(3).toString());
        Question5View.setText("Question 5: "+All_Questions.get(4).toString());
    }

    public class Student_GetQuizQuestions extends AsyncTask {
        public Student_GetQuizQuestions(){}
        @Override
        protected Object doInBackground(Object[] objects) {
            String link = "http://10.0.2.2/Student_GetQuestions.php?TopicName="+Topic_name;
            OkHttpClient client = new OkHttpClient();
            okhttp3.Request request = new okhttp3.Request.Builder()
                    .url(link)
                    .build();
            try {
                okhttp3.Response response = client.newCall(request).execute();
                String result = response.body().string();
                JSONObject jsonObject = new JSONObject(result);
                JSONArray questionsArray = jsonObject.getJSONArray("Questions");
                for (int i=0; i<questionsArray.length(); i++) {
                    JSONObject instructor = questionsArray.getJSONObject(i);
                    All_Questions.add(instructor.getString("Question"));
                }
                return true;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }


    public void FinishQuiz(View view){
        Answer1View = (EditText)findViewById(R.id.eT_Answer1);
        answer1 = Answer1View.getText().toString();
        Answer2View = (EditText)findViewById(R.id.eT_Answer2);
        answer2 = Answer2View.getText().toString();
        Answer3View = (EditText)findViewById(R.id.eT_Answer3);
        answer3 = Answer3View.getText().toString();
        Answer4View = (EditText)findViewById(R.id.eT_Answer4);
        answer4 = Answer4View.getText().toString();
        Answer5View = (EditText)findViewById(R.id.eT_Answer5);
        answer5 = Answer5View.getText().toString();
        try {
            String response = (String) new Student_AddQuizMarks().execute().get();
            Toast.makeText(getApplicationContext(),response,Toast.LENGTH_SHORT).show();
            StudentCoursesActivity.putExtra("Username",username);
            startActivity(StudentCoursesActivity);
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
    }


    public class Student_AddQuizMarks extends AsyncTask {
        public Student_AddQuizMarks(){}
        @Override
        protected Object doInBackground(Object[] objects) {
            String link = "http://10.0.2.2/AddQuizMarks.php?Username="+username+"&TopicName="+Topic_name+"&Answer1="+answer1+"&Answer2="+answer2+"&Answer3="+answer3+"&Answer4="+answer4+"&Answer5="+answer5;
            OkHttpClient client = new OkHttpClient();
            okhttp3.Request request = new okhttp3.Request.Builder()
                    .url(link)
                    .build();
            try {
                okhttp3.Response response = client.newCall(request).execute();
                String result = response.body().string();
                JSONObject jsonObject = new JSONObject(result);
                String the_response = jsonObject.getString("Success");
                return the_response;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
