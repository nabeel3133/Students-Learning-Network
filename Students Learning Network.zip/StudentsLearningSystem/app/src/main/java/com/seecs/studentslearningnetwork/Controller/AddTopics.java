package com.seecs.studentslearningnetwork.Controller;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.seecs.studentslearningnetwork.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import okhttp3.OkHttpClient;

public class AddTopics extends AppCompatActivity {

    Spinner courses_spinner;
    EditText TopicName;

    String username;
    String topic_name;
    String TAG = "MYTAG";
    int selected_course;
    ArrayList<String> Courses_Names = new ArrayList<String>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_topics);

        Bundle bundle = getIntent().getExtras();
        username = bundle.getString("Username");
        Log.d(TAG,"Username is: "+username);

        courses_spinner =(Spinner) findViewById(R.id.sP_SelectCourse);

        try {
            boolean success = (Boolean) new Instuctor_GetCourses().execute().get();
        }
        catch (Exception ex){
            ex.printStackTrace();
        }

        ArrayAdapter<String> adapter= new ArrayAdapter<String>(this,android.
                R.layout.simple_spinner_dropdown_item ,Courses_Names);
        courses_spinner.setAdapter(adapter);
        courses_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                selected_course=courses_spinner.getSelectedItemPosition();
                Toast.makeText(getBaseContext(), "You have selected Course: " + Courses_Names.get(selected_course),
                        Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });

    }

    public class Instuctor_GetCourses extends AsyncTask {
        public Instuctor_GetCourses(){}
        @Override
        protected Object doInBackground(Object[] objects) {
            String link = "http://10.0.2.2/Instructor_GetCourses.php?Username="+username;
            OkHttpClient client = new OkHttpClient();
            okhttp3.Request request = new okhttp3.Request.Builder()
                    .url(link)
                    .build();
            try {
                okhttp3.Response response = client.newCall(request).execute();
                String result = response.body().string();
                JSONObject json = new JSONObject(result);
                JSONObject jsonObject = new JSONObject(result);
                JSONArray jsonArray = jsonObject.getJSONArray("Courses");
                for (int i=0; i<jsonArray.length(); i++) {
                    JSONObject instructor = jsonArray.getJSONObject(i);
                    Courses_Names.add(instructor.getString("Subject_Name"));
                }
                return true;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }


    public class Instuctor_AddCompletedTopic extends AsyncTask {
        public Instuctor_AddCompletedTopic(){}
        @Override
        protected Object doInBackground(Object[] objects) {
            TopicName = (EditText)findViewById(R.id.eT_TopicName);
            topic_name = TopicName.getText().toString();
            String link = "http://10.0.2.2/Instructor_AddTopic.php?CourseName="+Courses_Names.get(selected_course)+"&TopicName="+topic_name;
            OkHttpClient client = new OkHttpClient();
            okhttp3.Request request = new okhttp3.Request.Builder()
                    .url(link)
                    .build();
            try {
                okhttp3.Response response = client.newCall(request).execute();
                String result = response.body().string();
                JSONObject json = new JSONObject(result);
                if(json.names().get(0).toString().equals("Success"))
                {
                    String the_response = json.getString("Success");
                    return the_response;
                }
                else if(json.names().get(0).toString().equals("AddedAlready"))
                {
                    String the_response = json.getString("AddedAlready");
                    return the_response;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    public void addTopic(View view){
        try{
        String response = (String) new Instuctor_AddCompletedTopic().execute().get();
        Log.d(TAG,"The response is: "+response);
        Toast.makeText(getBaseContext(), response, Toast.LENGTH_SHORT).show();
        } catch (Exception ex){
        ex.printStackTrace();
        }
    }
}
