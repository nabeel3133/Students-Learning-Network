package com.seecs.studentslearningnetwork.Controller;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.seecs.studentslearningnetwork.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Instructor_NewsFeed extends AppCompatActivity {

    Intent AddTopicsActivity;
    Intent MessengerActivity;
    Intent LogoutActivity;
    Intent CreateQuizActivity;
    ListView instlist;
    EditText newsmessage;
    EditText newstitle;
    String title;
    String news;
    String username;
    ArrayList <String> allnews = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructor__news_feed);
        Bundle bundle = getIntent().getExtras();
        username = bundle.getString("Username");
        instlist = (ListView)findViewById(R.id.instlist);
        try
        {
         new loadnews().execute().get();
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, android.R.id.text1,allnews);
        instlist.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.instructor_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        AddTopicsActivity = new Intent(getApplicationContext(),AddTopics.class);
        MessengerActivity = new Intent(getApplicationContext(),Sessions.class);
        LogoutActivity = new Intent(getApplicationContext(),LoginAndSignup.class);
        CreateQuizActivity = new Intent(getApplicationContext(),CreateQuiz.class);
        AddTopicsActivity.putExtra("Username",username);
        CreateQuizActivity.putExtra("Username",username);
        LogoutActivity.putExtra("Username",username);
        MessengerActivity.putExtra("Username",username);
        int id = item.getItemId();
        switch (id){
            case R.id.add_completed_topics:
                Toast.makeText(Instructor_NewsFeed.this, "Taking you to Add Topics", Toast.LENGTH_LONG).show();
                startActivity(AddTopicsActivity);
                break;

            case R.id.create_quiz:
                String TAG = "MYTAG";
                Log.d(TAG,"1");
                Toast.makeText(Instructor_NewsFeed.this, "Taking you to create quiz", Toast.LENGTH_LONG).show();
                startActivity(CreateQuizActivity);
                Log.d(TAG,"2");
                break;

            case R.id.instructor_inbox:
                Toast.makeText(Instructor_NewsFeed.this, "Opening Inbox", Toast.LENGTH_LONG).show();
                startActivity(MessengerActivity);
                break;

            case R.id.instructor_logout:
                String TAG2 = "MYTAG";
                Log.d(TAG2,"3");
                Toast.makeText(Instructor_NewsFeed.this, "Logged out successfully", Toast.LENGTH_LONG).show();
                Log.d(TAG2,"4");
                startActivity(LogoutActivity);
                break;
        }
        return true;
    }
    public class loadnews extends AsyncTask {

        public loadnews(){}
        @Override
        protected Object doInBackground(Object[] objects) {
            String link = "http://10.0.2.2/instnews.php?user="+username;
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(link)
                    .build();
            try {
                Response response = client.newCall(request).execute();
                // String result = response.body().string();
                String result = response.body().string();
                JSONObject json = new JSONObject(result);
                JSONArray jarray = json.getJSONArray("News");
                for (int i=0;i<jarray.length();i++)
                {
                    JSONObject id = jarray.getJSONObject(i);
                    //msgArray.add(id.getString("Message"));
                    allnews.add(id.getString("Quiz").toUpperCase()+"\t-"+id.getString("Student")+"-\nMarks: "+id.getString("Marks"));
                    //Log.d(TAG,"Id is: "+idarray.get(i));
                    //Log.d(TAG,"Topic name is: "+topicnamearray.get(i));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }
    public class postcontroller extends AsyncTask {

        public postcontroller(){}
        @Override
        protected Object doInBackground(Object[] objects) {
            String link = "http://10.0.2.2/savenews.php?title="+title+"&username="+username+"&news="+news;
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(link)
                    .build();
            try {
                Response response = client.newCall(request).execute();
 //               String result = response.body().string();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    public void onpostnews(View view)
    {
        newsmessage = (EditText) findViewById(R.id.newsmessage);
        newstitle = (EditText) findViewById(R.id.newstitle);
        title = newstitle.getText().toString();
        news = newsmessage.getText().toString();
        try {
            new postcontroller().execute().get();
   //         //Log.d(TAG,"Response: "+response);
            Toast.makeText(getBaseContext(), "Done", Toast.LENGTH_SHORT).show();
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }
}
