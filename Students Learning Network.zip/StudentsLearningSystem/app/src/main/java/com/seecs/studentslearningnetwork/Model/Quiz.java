package com.seecs.studentslearningnetwork.Model;

import java.util.List;

/**
 * Created by Nabeel Hussain Syed on 12/27/2017.
 */

public class Quiz {
    private int id;
    private int topic_id;
    private int marks;
    private List<Question> questions;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTopic_id() {
        return topic_id;
    }

    public void setTopic_id(int topic_id) {
        this.topic_id = topic_id;
    }

    public int getMarks() {
        return marks;
    }

    public void setMarks(int marks) {
        this.marks = marks;
    }
}
