package com.seecs.studentslearningnetwork.Controller;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import android.os.AsyncTask;
import com.android.volley.AuthFailureError;
//import com.android.volley.Request;
import com.android.volley.RequestQueue;
//import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.seecs.studentslearningnetwork.R;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CreateQuiz extends AppCompatActivity {
    Intent InsturctorHomePage;

    private String TAG = "MYTAG";
    Spinner topics_spinner;

    EditText editText_Question1;
    EditText editText_Question2;
    EditText editText_Question3;
    EditText editText_Question4;
    EditText editText_Question5;
    EditText editText_Answer1;
    EditText editText_Answer2;
    EditText editText_Answer3;
    EditText editText_Answer4;
    EditText editText_Answer5;

    private String question1;
    private String question2;
    private String question3;
    private String question4;
    private String question5;
    private String answer1;
    private String answer2;
    private String answer3;
    private String answer4;
    private String answer5;

    ArrayList<String> Topics_Names = new ArrayList<String>();
    int selected_topic;
    String topicName;
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_quiz);

        topics_spinner =(Spinner) findViewById(R.id.sP_selectTopic);

        Bundle bundle = getIntent().getExtras();
        username = bundle.getString("Username");
        Log.d(TAG,"Username is: "+username);
        try {
            boolean success = (Boolean) new Instuctor_GetTopics().execute().get();
        }
        catch (Exception ex){
            ex.printStackTrace();
        }


        ArrayAdapter<String> adapter= new ArrayAdapter<String>(this,android.
                R.layout.simple_spinner_dropdown_item ,Topics_Names);
        topics_spinner.setAdapter(adapter);
        topics_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                selected_topic=topics_spinner.getSelectedItemPosition();
                Toast.makeText(getBaseContext(), "You have selected Topic: " + Topics_Names.get(selected_topic),
                        Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });
    }

    public class Instuctor_GetTopics extends AsyncTask {
        public Instuctor_GetTopics(){}
        @Override
        protected Object doInBackground(Object[] objects) {
            String link = "http://10.0.2.2/Instructor_GetTopics.php?Username="+username;
            OkHttpClient client = new OkHttpClient();
            okhttp3.Request request = new okhttp3.Request.Builder()
                    .url(link)
                    .build();
            try {
                okhttp3.Response response = client.newCall(request).execute();
                String result = response.body().string();
                JSONObject json = new JSONObject(result);
                JSONObject jsonObject = new JSONObject(result);
                JSONArray jsonArray = jsonObject.getJSONArray("TopicNames");
                for (int i=0; i<jsonArray.length(); i++) {
                    JSONObject instructor = jsonArray.getJSONObject(i);
                    Topics_Names.add(instructor.getString("Name"));
                }
                return true;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }


    public class QuizController extends AsyncTask {

        public QuizController(){}
        @Override
        protected Object doInBackground(Object[] objects) {
            String link = "http://10.0.2.2/CreateQuiz.php?TopicName="+Topics_Names.get(selected_topic)+"&Question1="+question1+"&Answer1="+answer1+"&Question2="+question2+"&Answer2="+answer2+"&Question3="+question3+"&Answer3="+answer3+"&Question4="+question4+"&Answer4="+answer4+"&Question5="+question5+"&Answer5="+answer5;
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(link)
                    .build();
            try {
                Response response = client.newCall(request).execute();
                String result = response.body().string();
                JSONObject json = new JSONObject(result);
                if(json.names().get(0).toString().equals("Success"))
                {
                    String the_response = json.getString("Success");
                    return the_response;
                }
                else if(json.names().get(0).toString().equals("AddedAlready"))
                {
                    String the_response = json.getString("AddedAlready");
                    return the_response;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }


    public void createQuiz(View view){
        editText_Question1 = (EditText)findViewById(R.id.eT_Question1);
        question1 = editText_Question1.getText().toString();
        editText_Question2 = (EditText)findViewById(R.id.eT_Question2);
        question2 = editText_Question2.getText().toString();
        editText_Question3 = (EditText)findViewById(R.id.eT_Question3);
        question3 = editText_Question3.getText().toString();
        editText_Question4 = (EditText)findViewById(R.id.eT_Question4);
        question4 = editText_Question4.getText().toString();
        editText_Question5 = (EditText)findViewById(R.id.eT_Question5);
        question5 = editText_Question5.getText().toString();

        editText_Answer1 = (EditText)findViewById(R.id.eT_Answer1);
        answer1 = editText_Answer1.getText().toString();
        editText_Answer2 = (EditText)findViewById(R.id.eT_Answer2);
        answer2 = editText_Answer2.getText().toString();
        editText_Answer3 = (EditText)findViewById(R.id.eT_Answer3);
        answer3 = editText_Answer3.getText().toString();
        editText_Answer4 = (EditText)findViewById(R.id.eT_Answer4);
        answer4 = editText_Answer4.getText().toString();
        editText_Answer5 = (EditText)findViewById(R.id.eT_Answer5);
        answer5 = editText_Answer5.getText().toString();
        try {
            String response = (String) new QuizController().execute().get();
            Log.d(TAG,"Response: "+response);
            if(response.equals("Quiz Created Successfully")) {
                Toast.makeText(getBaseContext(), response, Toast.LENGTH_SHORT).show();
                InsturctorHomePage = new Intent(getApplicationContext(), Instructor_NewsFeed.class);
                InsturctorHomePage.putExtra("Username", username);
                startActivity(InsturctorHomePage);
            }
            else
            {
                Toast.makeText(getBaseContext(), response, Toast.LENGTH_SHORT).show();
            }
        }catch (Exception ex){

            ex.printStackTrace();
        }
    }
}
