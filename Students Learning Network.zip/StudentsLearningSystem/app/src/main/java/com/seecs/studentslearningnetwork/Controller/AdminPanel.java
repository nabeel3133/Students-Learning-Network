package com.seecs.studentslearningnetwork.Controller;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.seecs.studentslearningnetwork.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import okhttp3.OkHttpClient;

public class AdminPanel extends AppCompatActivity {

    private String TAG = "MYTAG";
    Spinner courses_spinner, instructors_spinner;
    String[] Courses = {
            "Mathematics",
            "Chemistry",
            "English",
            "Computer Science",
            "Physics",
    };

    ArrayList<String> Instructors_Names = new ArrayList<String>();

    int selected_course, selected_instructor;

    private static final String GetInstructors_URL = "http://10.0.2.2/GetAll_Instructors.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_panel);

        courses_spinner =(Spinner) findViewById(R.id.sP_selectCourse);
        instructors_spinner =(Spinner) findViewById(R.id.sP_selectInstructor);

        try {
            boolean success = (Boolean) new AdminController_GetInstructors().execute().get();
        }
        catch (Exception ex){
            ex.printStackTrace();
        }

        ArrayAdapter<String> adapter= new ArrayAdapter<String>(this,android.
                R.layout.simple_spinner_dropdown_item ,Courses);
        courses_spinner.setAdapter(adapter);
        courses_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                selected_course=courses_spinner.getSelectedItemPosition();
                Toast.makeText(getBaseContext(), "You have selected Course: " + Courses[selected_course],
                        Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });


        ArrayAdapter<String> adapter2= new ArrayAdapter<String>(this,android.
                R.layout.simple_spinner_dropdown_item ,Instructors_Names);
        instructors_spinner.setAdapter(adapter2);
        instructors_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                selected_instructor=instructors_spinner.getSelectedItemPosition();
                Toast.makeText(getBaseContext(), "You have selected Instructor: " + Instructors_Names.get(selected_instructor),
                        Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });
    }


    public class AdminController_GetInstructors extends AsyncTask {
        public AdminController_GetInstructors(){}
        @Override
        protected Object doInBackground(Object[] objects) {
            OkHttpClient client = new OkHttpClient();
            okhttp3.Request request = new okhttp3.Request.Builder()
                    .url(GetInstructors_URL)
                    .build();
            try {
                okhttp3.Response response = client.newCall(request).execute();
                String result = response.body().string();
                JSONObject json = new JSONObject(result);
                JSONObject jsonObject = new JSONObject(result);
                JSONArray jsonArray = jsonObject.getJSONArray("Instructors");
                for (int i=0; i<jsonArray.length(); i++) {
                    JSONObject instructor = jsonArray.getJSONObject(i);
                    Instructors_Names.add(instructor.getString("Username"));
                }
                return true;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    public class AdminController_AssignCourse extends AsyncTask {
        public AdminController_AssignCourse(){}
        @Override
        protected Object doInBackground(Object[] objects) {
            String link = "http://10.0.2.2/AdminPanelAssignCourse.php?Instructor="+Instructors_Names.get(selected_instructor)+"&Course="+(selected_course+1)+"&CourseName="+Courses[selected_course];
            OkHttpClient client = new OkHttpClient();
            okhttp3.Request request = new okhttp3.Request.Builder()
                    .url(link)
                    .build();
            try {
                okhttp3.Response response = client.newCall(request).execute();
                String result = response.body().string();
                JSONObject json = new JSONObject(result);
                if(json.names().get(0).toString().equals("Success"))
                {
                    String the_response = json.getString("Success");
                    return the_response;
                }
                else if(json.names().get(0).toString().equals("AddedAlready"))
                {
                    String the_response = json.getString("AddedAlready");
                    return the_response;
                }
                else
                {
                    String the_response = json.getString("error");
                    return the_response;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }


    public void AssignInstructor(View view){
        try {
            String response = (String) new AdminController_AssignCourse().execute().get();
            Toast.makeText(getBaseContext(), response, Toast.LENGTH_SHORT).show();
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.admin_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.logout:
                Toast.makeText(AdminPanel.this, "Logged out successfully", Toast.LENGTH_LONG).show();
                Intent i=new Intent(getApplicationContext(),LoginAndSignup.class);
                startActivity(i);
        }
        return true;
    }
}
