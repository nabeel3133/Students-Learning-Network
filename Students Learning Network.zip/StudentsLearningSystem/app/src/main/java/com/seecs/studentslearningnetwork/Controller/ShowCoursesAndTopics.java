package com.seecs.studentslearningnetwork.Controller;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.seecs.studentslearningnetwork.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import okhttp3.OkHttpClient;

public class ShowCoursesAndTopics extends AppCompatActivity {

    String TAG = "MYTAG";

    Intent AttemptQuizActivity;
    Intent StudentHomeActivity;
    Intent MessengerActivity;
    Intent LogoutActivity;

    ListView MathView;
    ListView ChemView;
    ListView EnglishView;
    ListView ComputerView;
    ListView PhysicsView;

    private static final String GetTopics_URL = "http://10.0.2.2/Student_GetTopics.php";


    ArrayList<String> Maths_Topics = new ArrayList<String>();
    ArrayList<String> Chemistry_Topics = new ArrayList<String>();
    ArrayList<String> English_Topics = new ArrayList<String>();
    ArrayList<String> ComputerScience_Topics = new ArrayList<String>();
    ArrayList<String> Physics_Topics = new ArrayList<String>();

    String username;
    String Topic_Name;
    String the_response;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_topics);

        Bundle bundle = getIntent().getExtras();
        username = bundle.getString("Username");

        AttemptQuizActivity = new Intent(getApplicationContext(),AttemptQuiz.class);

        try {
            boolean AllTopics = (Boolean) new Student_GetTopics().execute().get();
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
        MathView = (ListView) findViewById(R.id.lV_Mathematics);
        ChemView = (ListView) findViewById(R.id.lV_Chemistry);
        EnglishView = (ListView) findViewById(R.id.lV_English);
        ComputerView = (ListView) findViewById(R.id.lV_Computer);
        //PhysicsView = (ListView) findViewById(R.id.lV_Physics);

        ArrayAdapter<String> MathAdapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                Maths_Topics);
        MathView.setAdapter(MathAdapter);

        ArrayAdapter<String> ChemistryAdapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                Chemistry_Topics);
        ChemView.setAdapter(ChemistryAdapter);

        ArrayAdapter<String> EnglishAdapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                English_Topics);
        EnglishView.setAdapter(EnglishAdapter);

        ArrayAdapter<String> ComputerAdapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                ComputerScience_Topics);
        ComputerView.setAdapter(ComputerAdapter);

        MathView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> arg0, View v, int position,
                                    long arg3)
            {
                Topic_Name = arg0.getItemAtPosition(position).toString();
                try {
                    boolean CheckAttempted = (Boolean) new Student_CheckQuizAttempted().execute().get();
                    if(CheckAttempted)
                    {
                        AttemptQuizActivity.putExtra("TopicName",Topic_Name);
                        AttemptQuizActivity.putExtra("Username",username);
                        Toast.makeText(getApplicationContext(),the_response,Toast.LENGTH_SHORT).show();
                        startActivity(AttemptQuizActivity);
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),the_response,Toast.LENGTH_SHORT).show();
                    }
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            }
        });


        ChemView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> arg0, View v, int position,
                                    long arg3)
            {
                Topic_Name = arg0.getItemAtPosition(position).toString();
                try {
                    boolean CheckAttempted = (Boolean) new Student_CheckQuizAttempted().execute().get();
                    if(CheckAttempted)
                    {
                        AttemptQuizActivity.putExtra("TopicName",Topic_Name);
                        AttemptQuizActivity.putExtra("Username",username);
                        Toast.makeText(getApplicationContext(),the_response,Toast.LENGTH_SHORT).show();
                        startActivity(AttemptQuizActivity);
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),the_response,Toast.LENGTH_SHORT).show();
                    }
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            }
        });

        EnglishView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> arg0, View v, int position,
                                    long arg3)
            {
                Topic_Name = arg0.getItemAtPosition(position).toString();
                try {
                    boolean CheckAttempted = (Boolean) new Student_CheckQuizAttempted().execute().get();
                    if(CheckAttempted)
                    {
                        AttemptQuizActivity.putExtra("TopicName",Topic_Name);
                        AttemptQuizActivity.putExtra("Username",username);
                        Toast.makeText(getApplicationContext(),the_response,Toast.LENGTH_SHORT).show();
                        startActivity(AttemptQuizActivity);
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),the_response,Toast.LENGTH_SHORT).show();
                    }
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            }
        });

        ComputerView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> arg0, View v, int position,
                                    long arg3)
            {
                Topic_Name = arg0.getItemAtPosition(position).toString();
                try {
                    boolean CheckAttempted = (Boolean) new Student_CheckQuizAttempted().execute().get();
                    if(CheckAttempted)
                    {
                        AttemptQuizActivity.putExtra("TopicName",Topic_Name);
                        AttemptQuizActivity.putExtra("Username",username);
                        Toast.makeText(getApplicationContext(),the_response,Toast.LENGTH_SHORT).show();
                        startActivity(AttemptQuizActivity);
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),the_response,Toast.LENGTH_SHORT).show();
                    }
                }
                catch (Exception ex){
                    ex.printStackTrace();
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.student_coursesmenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        StudentHomeActivity = new Intent(getApplicationContext(),Student_NewsFeed.class);
        MessengerActivity = new Intent(getApplicationContext(),Messenger.class);
        LogoutActivity = new Intent(getApplicationContext(),LoginAndSignup.class);
        int id = item.getItemId();
        switch (id){
            case R.id.home:
                Toast.makeText(ShowCoursesAndTopics.this, "Opening Newsfeed", Toast.LENGTH_LONG).show();
                StudentHomeActivity.putExtra("Username",username);
                startActivity(StudentHomeActivity);
                break;

            case R.id.student_inbox:
                Toast.makeText(ShowCoursesAndTopics.this, "Opening Inbox", Toast.LENGTH_LONG).show();
                MessengerActivity.putExtra("Username",username);
                startActivity(MessengerActivity);
                break;

            case R.id.student_logout:
                Toast.makeText(ShowCoursesAndTopics.this, "Logged out successfully", Toast.LENGTH_LONG).show();
                LogoutActivity.putExtra("Username",username);
                startActivity(LogoutActivity);
                break;
        }
        return true;
    }


        public class Student_GetTopics extends AsyncTask {
        public Student_GetTopics(){}
        @Override
        protected Object doInBackground(Object[] objects) {
            OkHttpClient client = new OkHttpClient();
            okhttp3.Request request = new okhttp3.Request.Builder()
                    .url(GetTopics_URL)
                    .build();
            try {
                okhttp3.Response response = client.newCall(request).execute();
                String result = response.body().string();
                JSONObject jsonObject = new JSONObject(result);
                JSONArray mathArray = jsonObject.getJSONArray("Mathematics");
                for (int i=0; i<mathArray.length(); i++) {
                    JSONObject instructor = mathArray.getJSONObject(i);
                    Maths_Topics.add(instructor.getString("Name"));
                }

                JSONArray chemArray = jsonObject.getJSONArray("Chemistry");
                for (int i=0; i<chemArray.length(); i++) {
                    JSONObject instructor = chemArray.getJSONObject(i);
                    Chemistry_Topics.add(instructor.getString("Name"));
                }

                JSONArray englishArray = jsonObject.getJSONArray("English");
                for (int i=0; i<chemArray.length(); i++) {
                    JSONObject instructor = englishArray.getJSONObject(i);
                    English_Topics.add(instructor.getString("Name"));
                }

                JSONArray computerArray = jsonObject.getJSONArray("Computer Science");
                for (int i=0; i<chemArray.length(); i++) {
                    JSONObject instructor = computerArray.getJSONObject(i);
                    ComputerScience_Topics.add(instructor.getString("Name"));
                }
                return true;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    public class Student_CheckQuizAttempted extends AsyncTask {
        public Student_CheckQuizAttempted(){}
        @Override
        protected Object doInBackground(Object[] objects) {
            String link = "http://10.0.2.2/Student_CheckQuizAttempted.php?Username="+username+"&TopicName="+Topic_Name;
            OkHttpClient client = new OkHttpClient();
            okhttp3.Request request = new okhttp3.Request.Builder()
                    .url(link)
                    .build();
            try {
                okhttp3.Response response = client.newCall(request).execute();
                String result = response.body().string();
                JSONObject jsonObject = new JSONObject(result);
                if(jsonObject.names().get(0).toString().equals("Success"))
                {
                    the_response = jsonObject.getString("Success");
                    return true;
                }
                else if(jsonObject.names().get(0).toString().equals("AlreadyAttempted"))
                {
                    the_response = jsonObject.getString("AlreadyAttempted");
                    return false;
                }
                else if(jsonObject.names().get(0).toString().equals("QuizNotCreated"))
                {
                    the_response = jsonObject.getString("QuizNotCreated");
                    return false;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

}
