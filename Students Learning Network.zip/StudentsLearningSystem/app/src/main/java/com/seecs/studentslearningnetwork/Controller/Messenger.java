package com.seecs.studentslearningnetwork.Controller;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.seecs.studentslearningnetwork.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Messenger extends AppCompatActivity {
    Button sendButton;
    Button referButtton;
    ListView messages;
    EditText message;
    TextView title;
    String msgtxt;
    String sessiontitle;
    ArrayList<String> msgArray = new ArrayList<>();
    ArrayList<String> senderArray = new ArrayList<>();
    String sessionId;
    String username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_messenger);
        Bundle bundle = getIntent().getExtras();
        username = bundle.getString("Username");
        sessionId = bundle.getString("Session");
        try{
            new showtitle().execute().get();
        } catch (Exception ex){
            ex.printStackTrace();
        }
        title = (TextView) findViewById(R.id.sessiontitle);
        title.setText(sessiontitle);
        try {
            new getmessages().execute().get();
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
        messages = findViewById(R.id.msglist);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, android.R.id.text1,senderArray);
        messages.setAdapter(adapter1);
//        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_2, android.R.id.text2,msgArray);
//        messages.setAdapter(adapter2);
    }
    public void onrefer(View view)
    {
        try
        {
            new referinstructor().execute().get();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }

    }
    public void onsend(View view)
    {
        message = (EditText) findViewById(R.id.messagetext);
        msgtxt = (String) message.getText().toString();
        try
        {
           new sendmsg().execute().get();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        Intent i = new Intent(getApplicationContext(), Messenger.class);
        i.putExtra("Username",username);
        i.putExtra("Session",sessionId);
        startActivity(i);
    }
    public class showtitle extends AsyncTask {
        public showtitle(){}
        protected Object doInBackground(Object[] objects) {
            String link = "http://10.0.2.2/getsessiontitle.php?session="+sessionId;
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(link)
                    .build();
            try {
                Response response = client.newCall(request).execute();
                String result = response.body().string();
                JSONObject json = new JSONObject(result);
                sessiontitle = json.getString("Name");
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }
    public class referinstructor extends AsyncTask {
        public referinstructor(){}
        @Override
        protected Object doInBackground(Object[] objects) {
            String link = "http://10.0.2.2/referinstructor.php?user="+username+"&session="+sessionId;
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(link)
                    .build();
            try {
                Response response = client.newCall(request).execute();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }
    public class sendmsg extends AsyncTask {
        public sendmsg(){}
        @Override
        protected Object doInBackground(Object[] objects) {
            String link = "http://10.0.2.2/sendmessage.php?user="+username+"&message="+msgtxt+"&session="+sessionId;
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(link)
                    .build();
            try {
                String TAG = "MYTAG";
                Response response = client.newCall(request).execute();
                Log.d(TAG,"Response is: "+response);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }
    public class getmessages extends AsyncTask {
        public getmessages(){}
        @Override
        protected Object doInBackground(Object[] objects) {
            String link = "http://10.0.2.2/messages.php?session="+sessionId;
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(link)
                    .build();
            try {
                Response response = client.newCall(request).execute();
                String result = response.body().string();
                JSONObject json = new JSONObject(result);
                JSONArray jarray = json.getJSONArray("AllMessages");
                for (int i=0;i<jarray.length();i++)
                {
                    JSONObject id = jarray.getJSONObject(i);
                    //msgArray.add(id.getString("Message"));
                    senderArray.add(id.getString("Sender").toUpperCase()+"\n"+id.getString("Message"));
                    //Log.d(TAG,"Id is: "+idarray.get(i));
                    //Log.d(TAG,"Topic name is: "+topicnamearray.get(i));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
