package com.seecs.studentslearningnetwork.Controller;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.seecs.studentslearningnetwork.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Student_NewsFeed extends AppCompatActivity {

    Intent ShowCoursesActivity;
    Intent MessengerActivity;
    Intent LogoutActivity;

    private String username;
    ListView newslist; //= findViewById(R.id.listView3);
    ArrayList<String> allnews = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student__news_feed);

        Bundle bundle = getIntent().getExtras();
        username = bundle.getString("Username");
        newslist = (ListView)findViewById(R.id.listView3);
        try
        {
            new loadnews().execute().get();
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, android.R.id.text1,allnews);
        newslist.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.student_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        ShowCoursesActivity = new Intent(getApplicationContext(),ShowCoursesAndTopics.class);
        MessengerActivity = new Intent(getApplicationContext(),Sessions.class);
        LogoutActivity = new Intent(getApplicationContext(),LoginAndSignup.class);
        int id = item.getItemId();
        switch (id){
            case R.id.all_courses:
                Toast.makeText(Student_NewsFeed.this, "Showing you your courses and topics", Toast.LENGTH_LONG).show();
                ShowCoursesActivity.putExtra("Username",username);
                startActivity(ShowCoursesActivity);
                break;

            case R.id.student_inbox:
                Toast.makeText(Student_NewsFeed.this, "Opening Inbox", Toast.LENGTH_LONG).show();
                MessengerActivity.putExtra("Username",username);
                startActivity(MessengerActivity);
                break;

            case R.id.student_logout:
                Toast.makeText(Student_NewsFeed.this, "Logged out successfully", Toast.LENGTH_LONG).show();
                LogoutActivity.putExtra("Username",username);
                startActivity(LogoutActivity);
                break;
        }
        return true;
    }
    public class loadnews extends AsyncTask {
        public loadnews(){}
        @Override
        protected Object doInBackground(Object[] objects) {
            String link = "http://10.0.2.2/studnews.php";
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(link)
                    .build();
            try {
                Response response = client.newCall(request).execute();
                // String result = response.body().string();
                String result = response.body().string();
                JSONObject json = new JSONObject(result);
                JSONArray jarray = json.getJSONArray("News");
                for (int i=0;i<jarray.length();i++)
                {
                    JSONObject id = jarray.getJSONObject(i);
                    //msgArray.add(id.getString("Message"));
                    allnews.add(id.getString("title").toUpperCase()+"\n-"+id.getString("inst")+"-\n"+id.getString("news"));
                    //Log.d(TAG,"Id is: "+idarray.get(i));
                    //Log.d(TAG,"Topic name is: "+topicnamearray.get(i));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
