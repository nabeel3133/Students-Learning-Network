package com.seecs.studentslearningnetwork.Controller;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.seecs.studentslearningnetwork.R;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginAndSignup extends AppCompatActivity {
    private String TAG = "MYTAG";

    //View Fields
    private EditText Username, Password;
    private ToggleButton LoginOrSignup;
    private Button SigninOrSignup;
    private RadioGroup Type;
    private RadioButton Admin, Instructor, Student, SelectedButton;

    //Model/Data
    private String username, password, type, toggleButtonValue;
    private int type_id;

    private RequestQueue requestQueue;
    private static final String Signin_URL = "http://10.0.2.2/Signin.php";
    private static final String Signup_URL = "http://10.0.2.2/Signup.php";
    private StringRequest request;


    Intent AdminSigninActivity;
    Intent InstructorSigninActivity;
    Intent StudentSigninActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_and_signup);
    }


    public void LoginOrSignup(View view)
    {
        //Get values of all fields
        LoginOrSignup = (ToggleButton)findViewById(R.id.tB_SigninSignup);
        Username = (EditText) findViewById(R.id.eT_Username);
        Password = (EditText) findViewById(R.id.eT_Password);
        SigninOrSignup = (Button)findViewById(R.id.bT_LoginSignup);
        Type = (RadioGroup)findViewById(R.id.rG_Type);
        Admin = (RadioButton)findViewById(R.id.rB_Admin);
        Instructor = (RadioButton)findViewById(R.id.rB_Instructor);
        Student = (RadioButton)findViewById(R.id.rB_Student);
        requestQueue = Volley.newRequestQueue(this);

        type_id = Type.getCheckedRadioButtonId();
        SelectedButton = (RadioButton) findViewById(type_id);
        type = SelectedButton.getText().toString();
        username = Username.getText().toString();
        password = Password.getText().toString();
        toggleButtonValue = LoginOrSignup.getText().toString();

        if(toggleButtonValue.equals("Sign Up"))
        {
            request = new StringRequest(Request.Method.POST, Signup_URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        Log.d(TAG,response);
                        JSONObject jsonObject = new JSONObject(response);
                        if(jsonObject.names().get(0).toString().equals("Success")){
                            Toast.makeText(getApplicationContext(),jsonObject.getString("Success")+" as a "+type,Toast.LENGTH_SHORT).show();
                        }
                        else if(jsonObject.names().get(0).equals("alreadyExist")){
                            Toast.makeText(getApplicationContext(),"Username already Exists",Toast.LENGTH_SHORT).show();
                        }
                        else if(jsonObject.names().get(0).equals("empty")){
                            Toast.makeText(getApplicationContext(),"Fill all fields to sign up",Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(), "Error " +jsonObject.getString("error"), Toast.LENGTH_SHORT).show();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            }){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String,String> hashMap = new HashMap<String, String>();
                    hashMap.put("Username",username);
                    hashMap.put("Password",password);
                    hashMap.put("Type",type);
                    return hashMap;
                }
            };

            requestQueue.add(request);
        }

        else if(toggleButtonValue.equals("Sign In"))
        {
            request = new StringRequest(Request.Method.POST, Signin_URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        AdminSigninActivity = new Intent(getApplicationContext(),AdminPanel.class);
                        InstructorSigninActivity = new Intent(getApplicationContext(),Instructor_NewsFeed.class);
                        StudentSigninActivity = new Intent(getApplicationContext(),Student_NewsFeed.class);
                        Log.d(TAG,response);
                        JSONObject jsonObject = new JSONObject(response);
                        if(jsonObject.names().get(0).toString().equals("Success")){
                            Toast.makeText(getApplicationContext(),jsonObject.getString("Success")+" as a "+type,Toast.LENGTH_SHORT).show();
                            if(type.equals("Admin")){
                                AdminSigninActivity.putExtra("Username",username);
                                startActivity(AdminSigninActivity);
                            }
                            else if(type.equals("Instructor")){
                                InstructorSigninActivity.putExtra("Username",username);
                                startActivity(InstructorSigninActivity);
                            }
                            else if(type.equals("Student")){
                                StudentSigninActivity.putExtra("Username",username);
                                startActivity(StudentSigninActivity);
                            }
                        }

                        else if(jsonObject.names().get(0).equals("empty")){
                            Toast.makeText(getApplicationContext(),"Both fields are empty",Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(), jsonObject.getString("Invalid"), Toast.LENGTH_SHORT).show();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            }){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String,String> hashMap = new HashMap<String, String>();
                    hashMap.put("Username",username);
                    hashMap.put("Password",password);
                    hashMap.put("Type",type);
                    Log.d(TAG,"Username: "+username+" Password: "+password+" Type: "+type);
                    return hashMap;
                }
            };

            requestQueue.add(request);
        }

    }
}
